# -*- encoding: utf-8 -*-

VERSION = '2.0.0'
CLIENT_ID = ''
CLIENT_SECRET = ''
OAUTH_TOKEN = ''
APP_TOKEN = ''
