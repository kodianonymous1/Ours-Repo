# python-twitch for Kodi 
###### script.module.python.twitch

python-twitch for Kodi is module for interaction with the Twitch.tv API

#### Usage:
Example can be found [MrSprigster/Twitch-on-Kodi/master/resources/lib/addon/api.py](https://github.com/MrSprigster/Twitch-on-Kodi/blob/master/resources/lib/addon/api.py)

#### API Documentation:
https://dev.twitch.tv/docs

---
This Kodi module is a based on python-twitch https://github.com/ingwinlu/python-twitch
Thanks to ingwinlu for his continued work on the project.
